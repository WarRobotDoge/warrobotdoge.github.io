____________________________________

BookWorm Deluxe
version 1.0
02/15/2003

by PopCap
Distributed by RealNetworks, Inc.

____________________________________




VERSION HISTORY
____________________________________
 
1.00 Initial release!




TABLE OF CONTENTS
____________________________________


-  Minimum System Requirments

-  Instructions

-  Purchasing & Unlocking the Full Version

-  Technical Support

-  Copyright Information 







MINIMUM SYSTEM REQUIREMENTS
____________________________________


CPU -			Pentium, 300mhz or better
Minimum RAM -		64 MB
Supported OS's - 	Windows 95, 98, 2000, ME, or XP
Direct X - 		5.0 or higher
Sound -			Direct X certified sound card






GAMEPLAY INSTRUCTIONS
____________________________________


		-  QUICKSTART FOR A NEW GAME -

Click on the desktop shortcut or the "Play Now" button on the RealArcade game page to launch 
BookWorm Deluxe.



		     -  BASIC CONTROLS -

Click on any letter adjacent to the next to form words.  The bigger the word, the more points!




PURCHASING AND UNLOCKING THE FULL VERSION
____________________________________


If you are using RealArcade, simply click the "Buy Full Version Online" 
button on the BookWorm Deluxe game page in RealArcade.  After completing your 
purchase, RealArcade will automatically upgrade your game to the full 
version!




TECHNICAL SUPPORT
____________________________________

If you are experiencing problems with BookWorm Deluxe, please contact 
RealNetworks through our games support website at:

http://service.real.com/ragamesoptions.html

If you can, including the following information along with a 
description of your problem will help us to help you!

	-Title Of Game
	-Computer Manufacturer
	-Operating System (Windows 95, DOS 6.22, Etc.) 
	-CPU Type And Speed In Mhz
	-Amount Of RAM
	-Sound Card Type And Settings (Address, IRQ, DMA) 
	-Video Card
	-Mouse Driver And Version
	-A Copy Of The CONFIG.SYS And AUTOEXEC.BAT Files 



COPYRIGHT INFORMATION
____________________________________
BookWorm Deluxe (C)2002 PopCap  


