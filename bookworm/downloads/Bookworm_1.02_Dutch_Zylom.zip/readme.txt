======================
BOOKWORM DELUXE
version 1.0.1
February 19, 2003

by PopCap Games
presented by Zylom
======================

Thanks for downloading Bookworm Deluxe. We hope you enjoy the game!

VERSION HISTORY

1.00 Initial release!

=================
TABLE OF CONTENTS
=================

-  1.0 Required Specs And Recommended Specs
        1.1 Required Specs
        1.2 Recommended Spec

-  2.0 Troubleshooting/Compatibility
        2.1 Direct X
        2.2 Screen Color Depth	
        2.3 Bug Reporting

-  3.0 Playing the Game
        3.1 Goal
        3.2 Gameplay Basics
        3.3 Interface tips
        3.4 Burning Tiles
        3.5 Reward Tiles
        3.6 Bonus Word
        3.7 Game Types
        3.8 Classic Game
        3.9 Action Game

-  4.0 Options
        4.1 Music and Sound Effects
        4.2 Fullscreen
        4.3 Custom Cursors
        4.4 Help
        4.5 Tips
        4.6 Definitions
        4.7 Credits
        4.8 Register

-  5.0 Scoring
        5.1 Classic
        5.2 Action

-  6.0 Hall of Fame
        6.1 Local High Scores
        6.2 Internet High Scores

-  7.0 Registration
        7.1 Benefits of Registering
        7.2 How to Register
        7.3 Buy a Registration Code Online
        7.4 Enter Your Registration Code
        7.5 Problems?

-  8.0 Bookworm on the Internet

-  9.0 Technical Support

-  10.0 Credits

-  11.0 Software Use Limitations And Limited License

-  12.0 Copyright Information 

-  13.0 Localization


======================================
1.0 REQUIRED SPECS / RECOMMENDED SPECS
======================================

1.1 REQUIRED SYSTEM REQUIREMENTS

Bookworm DELUXE for Windows requires an IBM PC or 100% compatible computer,
with a Pentium II 300 Mhz or better processor. Your computer must have
at least 64 megabytes of RAM.

Operating System: you must be utilizing Windows 95, 98, 2000, or ME
with Direct X 7 or later to play Bookworm DELUXE for Windows on your system.

Controls: a keyboard and a 100% Microsoft compatible mouse are required.

Sound: you must have a Direct X certified sound card installed.

Video: you must have your desktop set to 16-bit or 32-bit Color
(256 Colors may not work properly).


1.2 RECOMMENDED SYSTEM REQUIREMENTS

PopCap recommends an IBM PC or 100% compatible computer, with a
Pentium II 500 Mhz or better processor and 128 megabytes of RAM.


===================================
2.0 TROUBLESHOOTING / COMPATIBILITY
===================================

For updates to this list go to www.popcap.com.

2.1  Direct X

Bookworm Deluxe requires you to have Direct X 7 drivers installed.
These are sound and video drivers from Microsoft used in
many games. If you need the latest version of Direct X, go to
http://www.microsoft.com/directx. 

2.2  Screen Color Depth

Bookworm Deluxe requires you to be running in 16bit color or better. It
may not function in Windowed mode properly in 256 colors. If you
are running in 256 colors, the game will try to switch to full
screen mode.

In addition, the game may run slowly in windowed mode in 32 bit
color. If this occurs, switch to full-screen mode, or change
your color depth to 16 bits.

2.3  Bug Reporting

Though we've tried our best to squash all the bugs, every once in
a while something we didn't expect pops up...

If you should come across a bug in Bookworm Deluxe, please report it to
bookworm@zylom.com.

If for some reason the program crashes, it will try to capture any
pertinent data and give you instructions on how to send that data
to PopCap. This is very helpful for tracking down glitches! This 
information is also stored in a file called CRASH.TXT in your
Bookworm directory (C:/PROGRAM FILES/POPCAP GAMES/BOOKWORM by
default). If you can, include this text file with any email you
send to PopCap about crashes.


====================
3.0 PLAYING THE GAME
====================

3.1 GOAL

The goal of Bookworm is to make words to feed the hungry Bookworm, while
watching out for burning letters that could ignite your library!

There are two game types: Classic and Action. But the basics remain the same
for both... click on tiles to link them together into words, then hit Submit
to clear them from the board. 

3.2 GAMEPLAY BASICS

In both game types, the basic interface is the same. You must create words by 
linking letters on the board together. To select a letter, just click on it. Then
select another letter adjacent to the first, and then another one adjacent to that,
until you have formed a word of at least 3 letters. When you have a valid word,
click the Submit button and it will be removed from the screen.

You can tell if your word is valid by looking at the sidebar... if there is a point
value under your word, the game accepts it as a real word.

Letters must be adjacent, and you can't backtrack... small green arrows will show
you the 'path' of the word you're creating.

3.3 INTERFACE TIPS

You can also Submit a word by double-clicking quickly on the last letter.

If you change your mind and want to deselect a letter in a word, just click on it
a second time. Or, you can just click on a letter not adjacent to your word and the focus will
switch to that one.

Right clicking will also deselect any letters you have selected.

You can also create a word by clicking and dragging a path... click on the first 
letter and hold the mouse down, then move the cursor over the letters in the
word you want to make. When you're over the final letter, release the mouse button.
If it'a valid word, it will automatically be submitted!

3.4 BURNING TILES

You'll see red tiles appear occasionally. Be careful! If you let them hit the
bottom of the screen, your game will end! You can get rid of burning tiles by
using them in words like any other letter. 

3.5 REWARD TILES

Green tiles appear randomly and increase word scores! Earn gold tiles by creating 
words containing 5 letters or more. Gold tiles are worth more than green ones! 
Combine 2 or more reward tiles in a word for higher word scores! Plus, you can earn 
Diamond and Sapphire tiles!

3.6 BONUS WORD

Starting on the second level, you'll see a Bonus Word appear beneath the Bookworm.
If you complete this word you'll score extra points! The more Bonus Words you complete
in a single game, the bigger the bonuses!

3.7 GAME TYPES

After the game loads, you will see a screen allowing you to choose Classic
or Action games. New players should start with Classic mode, while experienced
Bookworm players may prefer the more frenetic Action mode.

3.8 CLASSIC GAME

This is the original game of Bookworm. You have as much time as you want to make
each move, so you can can carefully consider every letter if you like.

In the Classic game, burning red tiles will appear after a certain number of moves.
As you go up in levels, red tiles will appear more frequently. Red tiles will
burn through normal tiles with every passing turn. If they reach the bottom of
the stack, they will ignite the library, ending your game.

3.9 ACTION GAME

The Action game is a more fast-paced real-time version of Bookworm. In this mode,
burning red tiles appear automatically every few seconds, whether you move or not!
And they will burn down through your library the same way, so you have to think fast!

Action mode is tougher than Classic mode, but you will earn more points if you survive!


===========
4.0 OPTIONS
===========

You can change game settings by clicking the OPTIONS button on the sidebar.

4.1 MUSIC AND SOUND EFFECTS

The two sliders at the top of the Options dialog control the volume of the
sound effects and music. You can adjust them separately. If you want to turn
the music or sound off completely, just drag the slider all the way to the
left.

4.2 FULLSCREEN

The Fullscreen option is enabled by checking the box next to it. This will
cause Bookworm to take up the whole screen. Some players may prefer this,
while others may like it better in a window, where they can easily switch
to other applications. To change back to windowed mode, just uncheck the
Fullscreen box.

4.3 CUSTOM CURSORS

This option will enable custom cursors within Bookworm, instead of using
your default Windows cursors. If you have an unusual Windows theme, or are
otherwise seeing strange mouse cursor behavior, you may want to enable this
option.

4.4 HELP

Clicking this button will bring up a brief screen with instructions on your
selected game mode.

4.5 TIPS

When Tips are checked, boxes will appear during play giving you instructions
on how to play the game. You can disable these during gameplay, or by unchecking
this box in Options.

4.6 DEFINITIONS

When Definitions are on, Lex the Bookworm will give you the definitions for
selected words when you create them... usually exotic or unusual ones. If you
don't like this feature, you can turn it off in the Options menu.

4.7 CREDITS

Click this to see the fine folks who brought you Bookworm!

4.8 REGISTER

Click this button to register your game via the internet. See the section
on 7.0 REGISTRATION.

===========
5.0 SCORING
===========

5.1 CLASSIC SCORING

You score points based on the length of your word and the rarity of the
letters in it. The formula is:

Add the numbers on all letters in the word together (for instance, 1 + 1 + 2)
Add the current level number
Multiply by the number of letters in the word

Reward tiles will then multiply this total further, so you can get truly
stratospheric values!

You will also receive bonus points for completing a Bonus Word. The more Bonus
Words you complete in a single game, the more bonus points each is worth.


5.2 ACTION SCORING

Action Scoring is similar to Classic scoring.

==================
6.0 HALL OF FAME
==================

You can visit the Hall of Fame from either the main game selector screen,
or after a game. This lets you submit and see the high scores and best words
players have made in the game!


6.1 LOCAL HIGH SCORES

The Hall of Fame contains the high scores achieved on your own personal computer.
It also shows the best and longest words you've completed. If you want to compare
yourself to other Bookworm players around the world, you need to visit the
Internet High Scores page by clicking the wreath in the top right corner.

6.2 INTERNET HIGH SCORES

When you click the wreath in the top right corner of the High Scores screen, the
program will attempt to connect you to the internet. If you're not already connected,
you may need to quit the program, connect, and try again.

The Internet High Scores are just like the Hall of Fame, but they contain the
best scores and words from around the world. After a game, you can submit your data
for consideration here!

WARNING! The alias you choose to use on the Internet High Scores page will be visible
to any players of the game, so don't use your real name if that makes you uncomfortable.
Using any sort of offensive language, racial or ethnic slurs and so on, or attempting
to hack any part of the system, will result in permanent banning from PopCap servers.


==================
7.0 REGISTRATION
==================

If you enjoy playing the Trial version of Bookworm Deluxe, sooner or later
you'll need to register!

7.1 BENEFITS OF REGISTERING

When you register, it removes all the annoying nag screens and limits from the game,
and other features are enabled:

 * High scores are enabled
 * Internet high scores can be uploaded

7.2 HOW TO REGISTER

To unlock the game, you need to buy a registration code online, and then
enter it into Bookworm Deluxe.

7.3  BUY A REGISTRATION CODE ONLINE

If you're playing Bookworm Deluxe, click on the OPTIONS button on the sidebar
and then click REGISTER. A dialog will come up onscreen. Click the REGISTER
ONLINE link to launch your web browser. You'll need to have an active internet
connection!

Once you're there, follow the directions on the web site to purchase your
registration code. You can use your credit card online to buy it, or fax your
purchase in, or send a money order.

When complete, you will be given a registration code (a 20-character sequence
of letters and numbers) keyed to your name. Don't give this to anyone else! 

You will also receive a copy sent to your email address. You should write down
your registration code in case you ever have a computer crash or need to
reinstall Bookworm Deluxe for some other reason.

7.4  ENTER YOUR REGISTRATION CODE

You must launch Bookworm Deluxe to enter your registration code. Once the game
comes up, click on the REGISTER link on the loading screen, or from the OPTIONS
menu.

A dialog will come up with space for you to enter your name and registration
code. Type these in carefully! If you make a mistake, your code may not be
recognized. 

The easiest way to do this is to cut and paste the code from the email you were
sent, by highlighting the 20-digit number with your mouse, pressing ctrl-c to
copy the text, and then pressing ctrl-v to paste it into the registration
dialog in Bookworm Deluxe.

Be sure to use the same name you gave when you bought your registration code
online, or your registration may not be recognized. 

Once you've entered your name and registration code, click OK and your copy of
Bookworm Deluxe should now be registered. You will have full access to all the
game's features, with no delay at the loading screen!

7.5 PROBLEMS?

If the program doesn't seem to recognize your registration code, check carefully
that you've typed it in correctly. Using the cut-and-paste method described above
can help prevent mistakes. Also make sure you're using the same name you used to
register with.

If you can't get to the online registration site to buy your registration code, 
make sure your internet connection is working properly. You must be connected to
the internet. If it still doesn't work, check back in a little while to see if 
there was a temporary problem with our servers.

Lost your registration code? Email us at bookworm@zylom.com and we'll try to
recover it for you. Make sure to let us know the name of the game you bought,
the name you purchased it under, and the approximate date of purchase... this'll
make it a lot easier for us to search our records.

Don't have a credit card, or don't want to enter it online? You can choose to fax
your credit card number in, or send a money order instead, by selecting the
appropriate option on the Payment Method selector on the web page.

There is currently no way to buy a CDROM containing Bookworm Deluxe, but this 
could change in the future! There is also no version of the game available for
Macintosh computers yet. 

Hopefully this will answer all your questions, but if you're still having
difficulties, feel free to contact us at bookworm@zylom.com. Include as much
information as you can about the problem you're having, and we'll get back to you
as quickly as we can!


==============================
8.0 Bookworm ON THE INTERNET
==============================

PopCap Games, the creators of Bookworm Deluxe, have their home site at: 
www.popcap.com

Here you can play the web version of Bookworm, and many other
games besides!


======================
9.0 TECHNICAL SUPPORT
======================

If you are experiencing problems with Bookworm Deluxe, you can contact us at:

bookworm@zylom.com.

If you can, including the following information along with a 
description of your problem will help us to help you!

	-Title Of Game
	-Computer Manufacturer
	-Operating System (Windows 95, DOS 6.22, Etc.) 
	-CPU Type And Speed In Mhz
	-Amount Of RAM
	-Sound Card Type And Settings (Address, IRQ, DMA) 
	-Video Card
	-Mouse Driver And Version
	-A Copy Of The CONFIG.SYS And AUTOEXEC.BAT Files 

============
10.0 CREDITS
============

Bookworm Deluxe was created by PopCap Games.

Game Design:	        Jason Kapalka
Programming:	        Nick Newhard
PopCap Framework:	Brian Fiete
Art:		        Tysen Henderson
Rank Cartoons:		Gary Clair
Music:	 	        Skaven (www.futurecrew.com/skaven)
Biz:			Don Walters and John Vechey

Thanks to all our beta testers and players on
PopCap.com for their valuable feedback! 

=================================================
11.0 SOFTWARE USE LIMITATIONS AND LIMITED LICENSE
=================================================

GENERAL PRODUCT LICENSE.

This Copy Of Bookworm DELUXE (The "Software") Is Intended Solely
For Your Personal Non-Commercial Home Entertainment Use.  You May Not
Decompile, Reverse Engineer, Or Disassemble The Software, Except As 
Permitted By Law.  PopCap Corporation And Its Licensors Retain All
Right, Title And Interest In The Software Including All Intellectual
Property Rights Embodied Therein And Derivatives Thereof.  The Software,
Including, Without Limitation, All Code, Data Structures, Characters, 
Images, Sounds, Text, Screens, Game Play, Derivative Works And All
Other Elements Of The Software May Not Be Copied, Resold, Rented,
Leased, Distributed (Electronically Or Otherwise), Used On A 
Pay-Per-Play, Coin-Op Or Other For-Charge Basis, Or For Any Commercial
Purpose. Any Permissions Granted Herein Are Provided On A Temporary
Basis And Can Be Withdrawn By PopCap Games, Inc At Any Time.
All Rights Not Expressly Granted Are Reserved.

ACCEPTANCE OF LICENSE TERMS.

By Acquiring And Retaining This Software, You Assent To The Terms And
Restrictions Of This Limited License. If You Do Not Accept The Terms
Of This Limited License, Do Not Install or Use This Software.


===========================
12.0 COPYRIGHT INFORMATION
===========================

BOOKWORM DELUXE (C) 2002, 2003 PopCap Games, Inc.  
All Other Copyrights And Trademarks Are Property Of Their Respective
Owners.  All Rights Reserved.

=================
13.0 LOCALIZATION
=================

The localized versions of Bookworm acknowledge the use of wordlists, 
provided by various persons. Below is an overview of the various
acknowledgements:

SPANISH:
----
The list of Spanish words employed in this software is used with
the author's permission. It is Copyright � 1998 - 2003 Juan L. Varona,
and is made available under the following license:
<ftp://tex.unirioja.es/pub/tex/dict-win/00LEEME-README.txt>
The official repository of the list is <ftp://tex.unirioja.es/pub/tex/dict-win/>.
----

DUTCH:
----
The list of Dutch words employed in this software is used with
the author's permission. It is Copyright � 1999-2003 Piet Tutelaers <P.T.H.Tutelaers@tue.nl>,
and is made freely available under the terms of the GNU General
Public License. For further information concerning this license,
please visit the GNU Project Web Server <http://www.gnu.org/licenses/gpl.html>.
The repository of the list is <ftp://ftp.dante.de/pub/archive/systems/win32/winedt/dict/>.
----

ITALIAN:
----
The list of Italian words employed in this software is used with
the author's permission. It is Copyright � 1993-2003 Luigi M Bianchi <lbianchi@yorku.ca>,
and is made freely available under the terms of the GNU General
Public License. For further information concerning this license,
please visit the GNU Project Web Server <http://www.gnu.org/licenses/gpl.html>.
The official repository of the list is <http://www.yorku.ca/lbianchi/italian_words/index.html>.
----

GERMAN:
----
The list of German words employed in this software is used with
the author's permission. It is Copyright � 1998 - 2003 Colin Marquardt <colin@marquardt-home.de>,
and is made available in the public domain.
The repository of the list is <ftp://ftp.dante.de/pub/archive/systems/win32/winedt/dict/>.
----

FRENCH:
----
The list of French words employed in this software is used with
the author's permission. It is Copyright � 1998 - 2003 Nicolas Le Novere <lenov@pasteur.fr>,
and is made available in the public domain.
The repository of the list is <ftp://ftp.dante.de/pub/archive/systems/win32/winedt/dict/>.
----